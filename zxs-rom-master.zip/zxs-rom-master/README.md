# ZX Spectrum ROM

An assembly file listing to generate a 16K ROM for the ZX Spectrum. Syntax is for SjASMPlus.

The ZX Spectrum ROM code remain the copyright of Amstrad plc. See LICENSE.md for details.
